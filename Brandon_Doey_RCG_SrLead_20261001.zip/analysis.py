#!/usr/bin/env python
"""Auditable Alaska assessment. Run: conda run -n dev1 python analysis.py

Inputs are immutable. DQ01..DQ16 below are explicit data-quality policies.
No web data, unconfirmed stock-flow corrections, or test-set tuning are used.
"""
from pathlib import Path
import argparse, hashlib, json, itertools, math, os, csv
from decimal import Decimal, ROUND_HALF_UP
os.environ.setdefault('MPLCONFIGDIR', '/tmp/rcg_matplotlib')
import numpy as np
import pandas as pd
from scipy.stats import beta
from sklearn.linear_model import Ridge, LinearRegression
import statsmodels.formula.api as smf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'alaska_caribbean_food_consumption_UPDATE.csv'
OUT = ROOT / 'outputs'
TOL = 0.02  # DQ05: cent-rounded measurements; 0.02 allows accumulated rounding.
SEED = 2026
RULES = []
def rule(id, problem, decision, why, count):
    RULES.append(dict(id=id, problem=problem, decision=decision, why=why, count=int(count)))

def audit():
    raw = pd.read_csv(SOURCE)
    raw['source_data_row'] = np.arange(1, len(raw)+1)
    # DQ01: remove ONLY non-record footer rows; never infer a voyage ID.
    footer = raw.voyage_id.isna()
    rule('DQ01', 'Row without voyage/product metadata (spreadsheet subtotal)',
         'Exclude from all voyage metrics; preserve in excluded_footer.csv',
         'Not a voyage-product observation; including it double-counts Caribbean waste', footer.sum())
    raw.loc[footer].to_csv(OUT/'excluded_footer.csv', index=False)
    d = raw.loc[~footer].copy()
    # DQ02: whitespace trim only; no fuzzy product merges or unit conversion.
    text_cols = ['voyage_id','ship_name','region','food_category','product_name']
    changed = sum((d[c] != d[c].str.strip()).sum() for c in text_cols)
    for c in text_cols: d[c] = d[c].str.strip()
    rule('DQ02','Text spelling/whitespace','Trim outer whitespace only; keep all 24 product identities',
         'Fuzzy merges would combine different products or units',changed)
    dup = d.duplicated(['voyage_id','product_name'], keep=False)
    rule('DQ03','Duplicate voyage-product keys','Stop if present; do not sum or drop arbitrarily',
         'Unknown whether duplicate transactions or repeated exports',dup.sum())
    assert not dup.any(), 'Duplicate keys require a business decision'
    numeric = ['sailing_nights','pax_count','avg_pax_age','load_factor','sea_days_percent',
               'cost_per_unit','provisioned_qty','consumed_qty','waste_qty','provisioned-consumed']
    invalid = d[numeric].isna().any(axis=1) | ~np.isfinite(d[numeric]).all(axis=1)
    invalid |= (d[['sailing_nights','pax_count','cost_per_unit','provisioned_qty']] <= 0).any(axis=1)
    invalid |= (d.consumed_qty < 0) | ~d.load_factor.between(0,1) | ~d.sea_days_percent.between(0,1)
    invalid |= ~d.avg_pax_age.between(0,120)
    rule('DQ04','Missing/nonfinite values and impossible ranges',
         'Stop if any invalid numeric or required metadata value is found; do not impute',
         'Inputs are essential and arbitrary repairs could drive provisioning',invalid.sum())
    assert not invalid.any()
    assert not d[text_cols].isna().any().any()
    d['gap_qty'] = d.provisioned_qty-d.consumed_qty
    d['identity_matches_tolerance'] = (d.gap_qty-d.waste_qty).abs() <= TOL
    rule('DQ05','Recorded waste does not equal provisioned minus consumed',
         'Flag with absolute 0.02 tolerance; preserve waste and quantities unchanged',
         'No stock-flow ledger to determine which quantity is wrong',(~d.identity_matches_tolerance).sum())
    helper_bad = (d.gap_qty-d['provisioned-consumed']).abs()>TOL
    rule('DQ06','Manually added helper difference', 'Recompute gap_qty from source quantities; audit helper',
         'Helper is a check, never a modeling feature',helper_bad.sum())
    provided_flag = d['match'].astype(str).str.lower().map({'true':True,'false':False})
    d['match_flag_disagrees'] = provided_flag != d.identity_matches_tolerance
    rule('DQ07','Boolean match flag disagrees with tolerance-based arithmetic',
         'Ignore supplied match as authority; use recomputed arithmetic and independent validity rules',
         'Exact floating-point equality and negative matching arithmetic do not establish data validity',
         d.match_flag_disagrees.sum())
    # USER CONFIRMED: zero waste is a data-quality issue; never call it true zero.
    d['zero_waste_invalid'] = d.waste_qty.eq(0)
    rule('DQ08','Zero waste is invalid (user-confirmed)',
         'Quarantine whole row from primary fit/economic comparisons; retain for demand stress test',
         'All these records also have consumption above recorded provisioned; cause unconfirmed',
         d.zero_waste_invalid.sum())
    # Negative can have a valid stock-flow/adjustment case, but none is documented.
    d['negative_waste_unresolved'] = d.waste_qty.lt(0)
    rule('DQ09','Negative waste needs a valid use case',
         'Preserve signed original; quarantine pending documented returns/transfers/adjustments; never abs()',
         'No valid explanation has been supplied; arithmetic agreement alone is insufficient',
         d.negative_waste_unresolved.sum())
    d['over_consumption_unresolved'] = d.gap_qty.lt(-TOL)
    rule('DQ10','Consumption exceeds recorded loading',
         'Quarantine primary; use original consumption only in explicitly conditional stress fit/test',
         'Could indicate beginning inventory, replenishment, demand, or recording error',
         d.over_consumption_unresolved.sum())
    d['primary_valid'] = ~(d.zero_waste_invalid | d.negative_waste_unresolved |
                           d.over_consumption_unresolved | ~d.identity_matches_tolerance)
    metadata = ['ship_name','region','sailing_nights','pax_count','avg_pax_age','load_factor','sea_days_percent']
    inconsist = d.groupby('voyage_id')[metadata].nunique().gt(1).any(axis=1)
    rule('DQ11','Repeated voyage metadata and incomplete product panels',
         'Assert consistent metadata and exactly 24 distinct products per voyage; count exposure once',
         '24 rows describe one voyage, not 24 independent voyages',inconsist.sum())
    assert not inconsist.any()
    assert d.groupby('voyage_id').product_name.nunique().eq(24).all()
    assert d.groupby('product_name').food_category.nunique().eq(1).all()
    rule('DQ12','Quantities combine pounds and counts; per-product units/case sizes absent',
         'Keep native quantities per product; never interpret cross-product sums as weight; round up to 1 native unit only',
         'Dollar aggregation is meaningful; case rounding and units need confirmation',24)
    rule('DQ13','Large within-product price variation',
         'Retain prices; use actual voyage prices in retrospective dollars and training-only Alaska medians for scenario',
         'No evidence to call positive prices errors; do not forecast regional price changes',24)
    rule('DQ14','No dates, stockouts, activity, menu, inventory carryover, or lead-time fields',
         'Use deterministic voyage holdout, not chronological validation; no activity/causal claims; label leftovers as proxy',
         'Consumed need not equal unconstrained demand; unused need not equal destroyed waste',50)
    rule('DQ15','Synthetic sample and only 25 Alaska voyages',
         'Pilot recommendation only; no automatic 2026 standard lock; uncertainty clustered by voyage',
         'Small sample does not establish future or simultaneous 24-product service guarantees',25)
    rule('DQ16','Ambiguous food scope and no authoritative current-policy formula',
         'Report FOOD separately and all 24 products; compare held-out actual loading, not an invented business standard',
         'Email totals include FOOD, BEVERAGE and SNACKS',1200)
    rule('DQ17','Quarantine preferentially removes high recorded demand and more Caribbean records',
         'Report exclusion counts by region; score all-record demand stress and refit a stress model',
         'Complete-case fitting can understate demand; historical zero shortage in valid-only comparison is by construction',
         (~d.primary_valid).sum())
    cap=d.drop_duplicates('voyage_id').copy()
    cap['implied_capacity']=cap.pax_count/cap.load_factor
    cap_range=cap.groupby('ship_name').implied_capacity.agg(['min','max'])
    varying=cap_range['max']/cap_range['min']>1.05
    cap_range.to_csv(OUT/'implied_ship_capacity.csv')
    rule('DQ18','Passengers/load imply varying capacity for the same ship (>5% range)',
         'Flag; keep provided pax/load separately; do not infer capacity or multiply passenger exposure by load again',
         'Rounding load to 0.01 cannot explain large differences; capacity definition needs confirmation',varying.sum())
    d['passenger_nights'] = d.sailing_nights*d.pax_count
    d['reported_waste_cost'] = d.waste_qty*d.cost_per_unit
    d['unused_qty_proxy'] = d.gap_qty.clip(lower=0)  # Derived proxy; source waste not overwritten.
    d['unused_cost_proxy'] = d.unused_qty_proxy*d.cost_per_unit
    d.to_csv(OUT/'audited_rows.csv', index=False)
    pd.DataFrame(RULES).to_csv(OUT/'data_quality_decisions.csv', index=False)
    return d

def features(d, model):
    if model=='mean': return np.zeros((len(d),1))
    sea=(d.sea_days_percent.to_numpy()-.65)/.15
    if model=='sea': return sea[:,None]
    return np.column_stack([sea,(d.sailing_nights.to_numpy()-10)/4,
                            (d.load_factor.to_numpy()-.8)/.2,(d.pax_count.to_numpy()-2600)/1000])

def fit_predict(train, target, model, column='consumed_qty'):
    y=train[column].to_numpy()/train.passenger_nights.to_numpy()
    if model=='mean': pred=np.full(len(target),y.mean())
    else:
        est=LinearRegression() if model=='sea' else Ridge(alpha=1.0)
        est.fit(features(train,model),y)
        pred=est.predict(features(target,model))
    return np.maximum(pred,0)

def cv_errors(train, model):
    # Each product has one row per voyage: omitting a product row omits its voyage
    # from that product's independent model. No other product is a predictor.
    errors=[]
    for ix in train.index:
        row=train.loc[[ix]]
        p=fit_predict(train.drop(index=ix),row,model)[0]
        errors.append(row.consumed_qty.iloc[0]/row.passenger_nights.iloc[0]-p)
    return np.array(errors)

def build_models(train, include_unresolved=False, chosen=None):
    data=train if include_unresolved else train.loc[train.primary_valid]
    scores={m:[] for m in ['mean','sea','profile_ridge']}
    if chosen is None:
        for product,t in data.groupby('product_name'):
            for m in scores:
                errors=cv_errors(t,m)
                scores[m].append(np.mean(np.abs(errors))/(t.consumed_qty/t.passenger_nights).mean())
        chosen=min(scores,key=lambda m:np.mean(scores[m]))
    models={}
    for product,t in data.groupby('product_name'):
        models[product]={'train':t,'errors':cv_errors(t,chosen),'model':chosen}
    return models,chosen,{m:float(np.mean(s)) if s else None for m,s in scores.items()}

def predict(models, target, q):
    out=[]
    for product,t in target.groupby('product_name'):
        spec=models[product]; train=spec['train']; errors=spec['errors']; n=len(errors)
        # DQ15: finite-sample rank adjusted empirical reserve; CV errors are not
        # independent split-conformal calibration. NO coverage guarantee claimed.
        rank=math.ceil((n+1)*q)
        reserve=max(0,float(np.sort(errors)[min(rank,n)-1]))
        rates=fit_predict(train,t,spec['model'])
        current=fit_predict(train,t,spec['model'],'provisioned_qty')
        for j,(_,r) in enumerate(t.iterrows()):
            pn=r.passenger_nights
            qty=math.ceil((rates[j]+reserve)*pn)
            scenarios=np.maximum((rates[j]+errors)*pn,0)
            waste=np.maximum(qty-scenarios,0)
            shortage=np.maximum(scenarios-qty,0)
            out.append({**r.to_dict(),'recommended_qty':qty,'predicted_consumption_qty':rates[j]*pn,
                        'expected_unused_qty':float(waste.mean()),'expected_short_qty':float(shortage.mean()),
                        'empirical_shortage_risk':float(np.mean(shortage>0)),
                        'calibration_voyages':n,'nominal_quantile':q,'rank_exceeds_sample':rank>n,
                        'reserve_rate':reserve,'estimated_current_practice_qty':float(current[j]*pn)})
    return pd.DataFrame(out)

def metrics(d):
    x=d.copy()
    x['new_unused_cost']=np.maximum(x.recommended_qty-x.consumed_qty,0)*x.cost_per_unit
    x['current_unused_cost']=np.maximum(x.provisioned_qty-x.consumed_qty,0)*x.cost_per_unit
    x['new_short_qty']=np.maximum(x.consumed_qty-x.recommended_qty,0)
    x['current_short_qty']=np.maximum(x.consumed_qty-x.provisioned_qty,0)
    x['new_shortfall_value']=x.new_short_qty*x.cost_per_unit
    x['current_shortfall_value']=x.current_short_qty*x.cost_per_unit
    x['purchase_saving']=(x.provisioned_qty-x.recommended_qty)*x.cost_per_unit
    x['unused_saving']=x.current_unused_cost-x.new_unused_cost
    v=x.groupby('voyage_id').agg(purchase_saving=('purchase_saving','sum'),unused_saving=('unused_saving','sum'),
        new_unused_cost=('new_unused_cost','sum'),current_unused_cost=('current_unused_cost','sum'),
        new_shortfall_value=('new_shortfall_value','sum'),current_shortfall_value=('current_shortfall_value','sum'),
        new_any_shortage=('new_short_qty',lambda z:bool((z>TOL).any())),
        current_any_shortage=('current_short_qty',lambda z:bool((z>TOL).any())))
    summary={c:float(x[c].sum()) for c in ['new_unused_cost','current_unused_cost','purchase_saving','unused_saving',
                                         'new_shortfall_value','current_shortfall_value']}
    summary.update(rows=len(x),voyages=len(v),new_shortage_rows=int((x.new_short_qty>TOL).sum()),
                   current_shortage_rows=int((x.current_short_qty>TOL).sum()),
                   new_any_shortage_voyages=int(v.new_any_shortage.sum()),
                   current_any_shortage_voyages=int(v.current_any_shortage.sum()),
                   unused_reduction_pct=100*summary['unused_saving']/summary['current_unused_cost'])
    rng=np.random.default_rng(SEED)
    boot=rng.choice(v.unused_saving.to_numpy(),(10000,len(v)),replace=True).mean(axis=1)
    summary['mean_unused_saving_bootstrap95']=np.quantile(boot,[.025,.975]).tolist()
    # Exact one-sided paired sign randomization; assumptions stated in report.
    dif=v.unused_saving.to_numpy()
    null=[np.mean(dif*np.array(s)) for s in itertools.product([-1,1],repeat=len(dif))]
    summary['one_sided_sign_randomization_p']=float(np.mean(np.array(null)>=dif.mean()-1e-8))
    summary['voyage_shortage_95_upper']=float(beta.ppf(.95,summary['new_any_shortage_voyages']+1,
         len(v)-summary['new_any_shortage_voyages'])) if summary['new_any_shortage_voyages']<len(v) else 1.
    return summary,x,v

def regional_analysis(d):
    v=d.drop_duplicates('voyage_id').copy()
    exposure=v.groupby('region').passenger_nights.sum()
    price=d.groupby('product_name').cost_per_unit.median()
    good=d.loc[d.primary_valid].copy()
    good['constant_price_consumption']=good.consumed_qty*good.product_name.map(price)
    # Complete native product basket at a common dollar valuation for age/sea diagnosis.
    # Conditional stress analysis uses original consumption including unresolved rows.
    allc=d.copy()
    allc['constant_price_consumption']=allc.consumed_qty*allc.product_name.map(price)
    allc['constant_price_unused']=allc.unused_qty_proxy*allc.product_name.map(price)
    basket=allc.groupby('voyage_id')[['constant_price_consumption','constant_price_unused']].sum()
    v=v.set_index('voyage_id').join(basket).reset_index()
    v['consumption_index']=v.constant_price_consumption/v.passenger_nights
    v['unused_index']=v.constant_price_unused/v.passenger_nights
    v['alaska']=(v.region=='ALASKA').astype(int)
    formula='consumption_index ~ alaska + avg_pax_age + sea_days_percent + sailing_nights + load_factor + pax_count'
    fit=smf.ols(formula,v).fit(cov_type='HC3')
    coeff=pd.DataFrame({'coefficient':fit.params,'lower95':fit.conf_int()[0],'upper95':fit.conf_int()[1],
                        'pvalue':fit.pvalues})
    coeff.to_csv(OUT/'hypothesis_regression.csv')
    # Clean-only check uses common product basket mean rates (not incomplete voyage sums).
    regional=[]
    for region,r in d.groupby('region'):
        rr=r.loc[r.primary_valid]
        regional.append(dict(region=region,voyages=r.voyage_id.nunique(),passenger_nights=float(exposure[region]),
            reported_quantity=float(r.waste_qty.sum()),reported_signed_cost=float(r.reported_waste_cost.sum()),
            valid_records=len(rr),quarantined_records=len(r)-len(rr),valid_waste_cost=float(rr.reported_waste_cost.sum()),
            proxy_unused_cost_all=float(r.unused_cost_proxy.sum()),
            proxy_unused_cost_per_passenger_night=float(r.unused_cost_proxy.sum()/exposure[region]),
            constant_price_consumption_per_passenger_night=float((r.consumed_qty*r.product_name.map(price)).sum()/exposure[region]),
            constant_price_consumption_clean_basket=float(sum(s.consumed_qty.sum()*price[p]/s.passenger_nights.sum() for p,s in rr.groupby('product_name')))))
    reg=pd.DataFrame(regional); reg.to_csv(OUT/'regional_summary.csv',index=False)
    cat=d.groupby(['region','food_category']).agg(reported_qty=('waste_qty','sum'),
        reported_signed_cost=('reported_waste_cost','sum'),unused_cost_proxy=('unused_cost_proxy','sum'))
    cat.to_csv(OUT/'category_summary.csv')
    # Exact 3-factor Shapley decomposition of ALL-ROW leftovers-cost proxy.
    # Per product factors: exposure, unused/native-unit rate, weighted price.
    parts=[]
    for product,p in d.groupby('product_name'):
        factors={}
        for region,r in p.groupby('region'):
            e=exposure[region]; u=r.unused_qty_proxy.sum(); c=r.unused_cost_proxy.sum()
            factors[region]=np.array([e,u/e,c/u])
        a=factors['ALASKA']; c=factors['CARIBBEAN']; contrib=np.zeros(3)
        for order in itertools.permutations(range(3)):
            z=c.copy()
            for j in order:
                before=np.prod(z); z[j]=a[j]; contrib[j]+=(np.prod(z)-before)/6
        parts.append(dict(product_name=product,exposure=contrib[0],unused_rate=contrib[1],price=contrib[2]))
    decomp=pd.DataFrame(parts);decomp.to_csv(OUT/'gap_decomposition.csv',index=False)
    assert abs(decomp[['exposure','unused_rate','price']].sum().sum()-
               (reg.iloc[0].proxy_unused_cost_all-reg.iloc[1].proxy_unused_cost_all))<.01
    # Relative per-product demand ratios, valid observations only; normalize by valid exposure.
    rates=good.groupby(['product_name','region']).apply(lambda r:r.consumed_qty.sum()/r.passenger_nights.sum(),include_groups=False).unstack()
    rates['alaska_vs_caribbean_pct']=100*(rates.ALASKA/rates.CARIBBEAN-1)
    rates.to_csv(OUT/'product_consumption_comparison.csv')
    # Primary age analysis avoids summing an incomplete product basket. Each valid
    # product's native consumption rate is indexed to its pooled valid mean rate,
    # then equally averaged within voyage. Product mix still varies after quarantine.
    pooled=good.groupby('product_name').apply(lambda r:r.consumed_qty.sum()/r.passenger_nights.sum(),include_groups=False)
    good['standardized_rate']=good.consumed_qty/good.passenger_nights/good.product_name.map(pooled)
    primary_v=v.copy()
    primary_v['standardized_index']=primary_v.voyage_id.map(good.groupby('voyage_id').standardized_rate.mean())
    primary_fit=smf.ols('standardized_index ~ alaska + avg_pax_age + sea_days_percent + sailing_nights + load_factor + pax_count',primary_v).fit(cov_type='HC3')
    primary_coeff=pd.DataFrame({'coefficient':primary_fit.params,'lower95':primary_fit.conf_int()[0],
        'upper95':primary_fit.conf_int()[1],'pvalue':primary_fit.pvalues})
    primary_coeff.to_csv(OUT/'hypothesis_regression_primary.csv')
    return reg,v,coeff,decomp,primary_coeff

def reconcile():
    # INDEPENDENT METHOD B: csv reader + Decimal string arithmetic, no pandas
    # cleaning functions/derived columns shared with method A.
    quantity=Decimal('0'); cost=Decimal('0'); count=0
    with SOURCE.open(newline='') as f:
        for r in csv.DictReader(f):
            if r['region']=='ALASKA' and r['voyage_id']:
                quantity+=Decimal(r['waste_qty']); cost+=Decimal(r['waste_qty'])*Decimal(r['cost_per_unit']);count+=1
    return {'decimal_alaska_reported_quantity':str(quantity),'decimal_alaska_signed_waste_cost':str(cost),
            'alaska_rows':count,'footer_excluded':True}

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--nights',type=int,default=10)
    parser.add_argument('--passengers',type=int,default=2600)
    parser.add_argument('--load-factor',type=float,default=.85)
    parser.add_argument('--sea-days-percent',type=float,default=.65,help='Fraction 0..1, not percentage points')
    args=parser.parse_args(argv)
    args.reserve_quantile=.95  # Fixed provisional policy; alternatives are sensitivity displays only.
    assert args.nights>0 and args.passengers>0 and 0<args.load_factor<=1 and 0<=args.sea_days_percent<=1
    assert .5<=args.reserve_quantile<1
    OUT.mkdir(exist_ok=True)
    d=audit(); reg,v,coeff,decomp,primary_coeff=regional_analysis(d)
    alaska=d.loc[d.region=='ALASKA']
    ids=np.array(sorted(alaska.voyage_id.unique()))
    test_ids=np.random.default_rng(SEED).choice(ids,5,replace=False)
    train=alaska.loc[~alaska.voyage_id.isin(test_ids)]
    test=alaska.loc[alaska.voyage_id.isin(test_ids)]
    assert set(train.voyage_id).isdisjoint(set(test.voyage_id))
    split=pd.DataFrame({'voyage_id':ids,'split':['test' if x in test_ids else 'train' for x in ids]})
    split.to_csv(OUT/'voyage_split.csv',index=False)
    models,chosen,scores=build_models(train)
    stress_models,_,_=build_models(train,include_unresolved=True,chosen=chosen)
    # The default recommendation is frozen before test outcomes are scored.
    predicted=predict(models,test,args.reserve_quantile)
    primary,rows,voyages=metrics(predicted.loc[predicted.primary_valid])
    stress,stressrows,stressvoyages=metrics(predicted)
    primary['evaluation']='valid records only';stress['evaluation']='all consumed values treated as demand (unconfirmed)'
    rows.to_csv(OUT/'holdout_primary_rows.csv',index=False)
    voyages.to_csv(OUT/'holdout_primary_voyages.csv')
    stressrows.to_csv(OUT/'holdout_stress_rows.csv',index=False)
    stressvoyages.to_csv(OUT/'holdout_stress_voyages.csv')
    # Planning profile is explicitly chosen, never inferred to be a supplied business fact.
    profile=train.groupby('product_name').first().reset_index()
    profile['voyage_id']='ILLUSTRATIVE_PROFILE'
    profile['sailing_nights']=args.nights; profile['pax_count']=args.passengers
    profile['load_factor']=args.load_factor;profile['sea_days_percent']=args.sea_days_percent
    profile['passenger_nights']=args.nights*args.passengers
    profile['cost_per_unit']=profile.product_name.map(train.groupby('product_name').cost_per_unit.median())
    # Check marginal training support; profile combos can still be out of joint support.
    support={c:dict(min=float(train[c].min()),max=float(train[c].max()),input=float(profile[c].iloc[0]))
             for c in ['sailing_nights','pax_count','load_factor','sea_days_percent']}
    for c,s in support.items():
        if not s['min']<=s['input']<=s['max']:
            raise ValueError(f'{c} outside training support {s}; refusing extrapolation')
    plan=predict(models,profile,args.reserve_quantile)
    stressplan=predict(stress_models,profile,args.reserve_quantile).set_index('product_name')
    plan['stress_fit_recommended_qty']=plan.product_name.map(stressplan.recommended_qty)
    plan['scenario_purchase_saving']=(plan.estimated_current_practice_qty-plan.recommended_qty)*plan.cost_per_unit
    plan['expected_unused_cost']=plan.expected_unused_qty*plan.cost_per_unit
    # Binomial upper risk bound is on held-out voyage-product events, NOT empirical CV risk.
    bounds={}
    for p,r in rows.groupby('product_name'):
        n=len(r);k=int((r.new_short_qty>TOL).sum())
        bounds[p]=(k,n,float(beta.ppf(.95,k+1,n-k)) if k<n else 1.)
    plan['holdout_shortage_events']=plan.product_name.map(lambda p:bounds[p][0])
    plan['holdout_valid_voyages']=plan.product_name.map(lambda p:bounds[p][1])
    plan['holdout_shortage_probability_95_upper']=plan.product_name.map(lambda p:bounds[p][2])
    columns=['product_name','food_category','recommended_qty','predicted_consumption_qty','expected_unused_qty',
        'expected_unused_cost','empirical_shortage_risk','expected_short_qty','calibration_voyages',
        'rank_exceeds_sample','holdout_shortage_events','holdout_valid_voyages','holdout_shortage_probability_95_upper',
        'cost_per_unit','estimated_current_practice_qty','scenario_purchase_saving','stress_fit_recommended_qty']
    plan[columns].to_csv(OUT/'alaska_product_recommendations.csv',index=False)
    params=[]
    for product,spec in models.items():
        t=spec['train'];y=t.consumed_qty/t.passenger_nights
        if chosen=='mean':intercept=float(y.mean());coef=np.zeros(1)
        else:
            est=LinearRegression() if chosen=='sea' else Ridge(alpha=1.0)
            est.fit(features(t,chosen),y);intercept=float(est.intercept_);coef=est.coef_
        params.append(dict(product_name=product,model=chosen,training_valid_voyages=len(t),
            intercept=intercept,coefficients=json.dumps(coef.tolist()),
            reserve_rate=float(plan.set_index('product_name').loc[product,'reserve_rate']),
            feature_definition='sea: (sea_days_fraction-0.65)/0.15; profile adds (nights-10)/4, (load-0.8)/0.2, (pax-2600)/1000'))
    pd.DataFrame(params).to_csv(OUT/'model_parameters.csv',index=False)
    # Sensitivities are reported, never used to retune the frozen default after seeing test.
    sensitivity=[]
    for q in [.80,.90,.95,.99]:
        pr=predict(models,test,q)
        m,_,_=metrics(pr.loc[pr.primary_valid]);ms,_,_=metrics(pr)
        pp=predict(models,profile,q)
        sensitivity.append(dict(quantile=q,valid_unused_cost=m['new_unused_cost'],
            valid_shortage_rows=m['new_shortage_rows'],valid_any_shortage_voyages=m['new_any_shortage_voyages'],
            stress_shortage_rows=ms['new_shortage_rows'],stress_shortfall_value=ms['new_shortfall_value'],
            scenario_order_cost=float((pp.recommended_qty*pp.cost_per_unit).sum())))
    pd.DataFrame(sensitivity).to_csv(OUT/'risk_frontier.csv',index=False)
    independently=reconcile()
    direct=float(alaska.waste_qty.sum()); signed=float(alaska.reported_waste_cost.sum())
    assert abs(Decimal(str(direct))-Decimal(independently['decimal_alaska_reported_quantity']))<Decimal('.000001')
    assert abs(Decimal(str(signed))-Decimal(independently['decimal_alaska_signed_waste_cost']))<Decimal('.000001')
    recon={**independently,'pandas_alaska_reported_quantity':direct,'pandas_alaska_signed_waste_cost':signed,
           'quantity_difference':float(Decimal(str(direct))-Decimal(independently['decimal_alaska_reported_quantity'])),
           'cost_difference':float(Decimal(str(signed))-Decimal(independently['decimal_alaska_signed_waste_cost'])),
           'interpretation':'Source reconciliation only: mixed native units and unresolved signed waste, not validated physical waste.'}
    # Second headline: independently recompute holdout saving from ORIGINAL source
    # strings plus frozen recommendation quantities. No audited flags or pandas
    # clip/aggregation are reused in Decimal method B.
    quantities={(r.voyage_id,r.product_name):Decimal(str(r.recommended_qty)) for r in predicted.itertuples()}
    savings_by_voyage={};current_dec=Decimal('0');new_dec=Decimal('0');decimal_valid_count=0
    with SOURCE.open(newline='') as f:
        for r in csv.DictReader(f):
            key=(r['voyage_id'],r['product_name'])
            if key not in quantities:continue
            p=Decimal(r['provisioned_qty']);c=Decimal(r['consumed_qty']);w=Decimal(r['waste_qty']);price=Decimal(r['cost_per_unit'])
            if w<=0 or c-p>Decimal('0.02') or abs(p-c-w)>Decimal('0.02'):continue
            historical=(p-c if p>c else Decimal('0'))*price
            proposed=(quantities[key]-c if quantities[key]>c else Decimal('0'))*price
            current_dec+=historical;new_dec+=proposed;decimal_valid_count+=1
            savings_by_voyage[r['voyage_id']]=savings_by_voyage.get(r['voyage_id'],Decimal('0'))+historical-proposed
    saving_dec=sum(savings_by_voyage.values(),Decimal('0'))
    assert decimal_valid_count==primary['rows']
    assert abs(Decimal(str(primary['unused_saving']))-saving_dec)<Decimal('.000001')
    recon.update(pandas_holdout_unused_saving=primary['unused_saving'],decimal_holdout_unused_saving=str(saving_dec),
        decimal_current_unused_cost=str(current_dec),decimal_new_unused_cost=str(new_dec),
        decimal_holdout_valid_rows=decimal_valid_count,
        decimal_saving_by_voyage={k:str(v) for k,v in savings_by_voyage.items()},
        saving_difference=float(Decimal(str(primary['unused_saving']))-saving_dec),
        reconciled_headline_cents=str(saving_dec.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)))
    (OUT/'headline_reconciliation.json').write_text(json.dumps(recon,indent=2))
    summary=dict(source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),seed=SEED,
        raw_rows=1201,records=len(d),valid_records=int(d.primary_valid.sum()),quarantined_records=int((~d.primary_valid).sum()),
        chosen_model=chosen,training_cv_relative_mae=scores,train_voyages=20,test_voyages=sorted(test_ids.tolist()),
        profile=vars(args),support=support,primary_holdout=primary,stress_holdout=stress,
        profile_order_cost=float((plan.recommended_qty*plan.cost_per_unit).sum()),
        profile_current_practice_estimate_cost=float((plan.estimated_current_practice_qty*plan.cost_per_unit).sum()),
        profile_purchase_saving=float(plan.scenario_purchase_saving.sum()),
        profile_expected_unused_cost=float(plan.expected_unused_cost.sum()),
        profile_stress_fit_order_cost=float((plan.stress_fit_recommended_qty*plan.cost_per_unit).sum()),
        profile_stress_fit_purchase_saving=float(((plan.estimated_current_practice_qty-plan.stress_fit_recommended_qty)*plan.cost_per_unit).sum()),
        projected_25_voyage_unused_saving=primary['unused_saving']/5*25,
        projected_25_voyage_purchase_saving=primary['purchase_saving']/5*25,
        projected_25_voyage_unused_saving_bootstrap95=[x*25 for x in primary['mean_unused_saving_bootstrap95']],
        gap_decomposition=decomp[['exposure','unused_rate','price']].sum().to_dict(),
        age_effect_per_year=float(coeff.loc['avg_pax_age','coefficient']),
        age_effect_ci95=coeff.loc['avg_pax_age',['lower95','upper95']].tolist(),
        sea_effect_10pct=float(coeff.loc['sea_days_percent','coefficient']*.1),
        sea_effect_10pct_ci95=(coeff.loc['sea_days_percent',['lower95','upper95']]*.1).tolist(),
        adjusted_region_effect=float(coeff.loc['alaska','coefficient']),
        adjusted_region_ci95=coeff.loc['alaska',['lower95','upper95']].tolist(),
        primary_age_effect_per_year=float(primary_coeff.loc['avg_pax_age','coefficient']),
        primary_age_ci95=primary_coeff.loc['avg_pax_age',['lower95','upper95']].tolist(),
        primary_sea_effect_10pct=float(primary_coeff.loc['sea_days_percent','coefficient']*.1),
        primary_sea_ci95=(primary_coeff.loc['sea_days_percent',['lower95','upper95']]*.1).tolist(),
        marginal_age_medians=v.groupby('region').avg_pax_age.median().to_dict(),
        no_activity_field=True,negative_scenario_demand_clipped_to_zero=True)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
    # Honest visualization: per-product demand ratios and held-out dollars.
    fig,axes=plt.subplots(1,2,figsize=(12,5.3),layout='constrained')
    ratios=pd.read_csv(OUT/'product_consumption_comparison.csv').sort_values('alaska_vs_caribbean_pct')
    axes[0].barh(ratios.product_name,ratios.alaska_vs_caribbean_pct,color='#167d8d')
    axes[0].axvline(0,color='#333333',lw=.8);axes[0].set_xlabel('Alaska consumption per passenger-night vs Caribbean (%)')
    axes[0].set_title('Valid records; unequal exclusions by region',loc='left',fontsize=11)
    axes[0].tick_params(axis='y',labelsize=8)
    axes[1].bar(['Historical loading','Recommendation'],
        [primary['current_unused_cost']/1e6,primary['new_unused_cost']/1e6],color=['#a5acb5','#167d8d'])
    axes[1].set_ylabel('Unused inventory value ($ million)')
    axes[1].set_title('5 held-out Alaska voyages; valid records only',loc='left',fontsize=11)
    fig.savefig(OUT/'evidence.png',dpi=180);plt.close(fig)
    from reporting import write_reports
    write_reports(ROOT,OUT,summary)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
