"""Create and execute the companion notebook in dev1 using IPython locally."""
from pathlib import Path
import sys
import nbformat
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output

ROOT=Path(__file__).resolve().parent
md=nbformat.v4.new_markdown_cell
code=nbformat.v4.new_code_cell
nb=nbformat.v4.new_notebook(cells=[
    md('''# Alaska provisioning: an auditable decision
This notebook executes the full pipeline, then exposes the decisions, product quantities, held-out tradeoffs and independent reconciliation. Source inputs remain unchanged. **Candidate for a controlled pilot; shortage tolerance and inventory stock flow are unconfirmed.**

The primary analysis treats zero waste as invalid and quarantines negative waste until a valid use case is documented, per the user's clarification. It never treats arithmetic agreement as proof of valid waste.

Run all cells from the project folder in `dev1`, or run `conda run -n dev1 python analysis.py`.'''),
    code('''from pathlib import Path
import json, io, contextlib
import pandas as pd
from IPython.display import display, Markdown, Image
import analysis
ROOT=Path(analysis.__file__).resolve().parent
OUT=ROOT/'outputs'
with contextlib.redirect_stdout(io.StringIO()) as run_log:
    analysis.main([])
print('Pipeline completed. Original inputs unchanged; generated results are in outputs/.')
s=json.loads((OUT/'summary.json').read_text())
pd.set_option('display.max_columns', 20)
pd.set_option('display.max_colwidth', 100)
pd.set_option('display.float_format', lambda x: f'{x:,.4f}')'''),
    md('''## 1. Data-quality decisions are visible in code
All DQ rules are applied in `analysis.audit()`. The table lists every decision and its reason. The row-level output retains source data row IDs and separate flags; original waste is never overwritten.'''),
    code("display(pd.read_csv(OUT/'data_quality_decisions.csv'))"),
    code('''d=pd.read_csv(OUT/'audited_rows.csv')
display(d.groupby('region').agg(records=('primary_valid','size'), eligible=('primary_valid','sum'),
    zero_invalid=('zero_waste_invalid','sum'), negative_unresolved=('negative_waste_unresolved','sum')))
display(d.loc[~d.primary_valid, ['source_data_row','voyage_id','product_name','provisioned_qty',
    'consumed_qty','waste_qty','gap_qty','zero_waste_invalid','negative_waste_unresolved']].head(12))'''),
    md('''## 2. Is the VP right?
The quoted quantity gap is 110.3%, but the quantities combine native units. Normalize consumption by passenger-nights **within product**, then compare. All valid product rates are higher in Alaska. Exclusions disproportionately remove high consumption and differ by region, so the comparison remains conditional. Activity is absent. The age regression is observational and its interval spans zero; it cannot establish an individual passenger-age effect.'''),
    code("display(pd.read_csv(OUT/'regional_summary.csv'))\ndisplay(pd.read_csv(OUT/'product_consumption_comparison.csv'))"),
    code("display(pd.read_csv(OUT/'hypothesis_regression_primary.csv'))\ndisplay(pd.read_csv(OUT/'gap_decomposition.csv')[['exposure','unused_rate','price']].sum().to_frame('Proxy-dollar gap attribution'))"),
    md('''## 3. Freeze the split and select using training only
All 24 products from each test voyage are held out together. Selection considers only training CV errors. The selected model predicts demand per passenger-night from sea-day share; nights and passengers scale exposure. Load is an input and support check, but the selected model assigns no extra load multiplier. No helper, waste, provisioning or test-demand variable predicts consumption.

The reserve is an empirical CV-tail estimate. It is **not** split-conformal calibration or a certified 95% service level. There are only 17–20 eligible training voyages per product.'''),
    code("display(pd.read_csv(OUT/'voyage_split.csv'))\ndisplay(pd.DataFrame.from_dict(s['training_cv_relative_mae'],orient='index',columns=['Training product-relative MAE']))\nprint('Selected model:',s['chosen_model'])"),
    code("display(pd.read_csv(OUT/'model_parameters.csv'))"),
    md('''## 4. Illustrative voyage: quantities, expected leftovers and risk
Default: 10 nights, 2,600 passengers, 85% load, 65% sea days. Units and case sizes remain unconfirmed. Each order is rounded up to one native unit. Expected unused quantity is calculated from CV-residual demand scenarios, not from a spoilage/plate-waste model.

Empirical calibration shortage is zero at the maximum-error reserve and is optimistic. Held-out observations and their large binomial upper bounds show how little is known about future risk. Those bounds describe the mixed held-out profiles, not this exact profile.'''),
    code("plan=pd.read_csv(OUT/'alaska_product_recommendations.csv')\ndisplay(plan)"),
    code('''display(pd.Series({
    'Primary candidate loading cost':s['profile_order_cost'],
    'Fitted historical loading proxy':s['profile_current_practice_estimate_cost'],
    'Primary profile loading saving':s['profile_purchase_saving'],
    'Expected unused value (proxy)':s['profile_expected_unused_cost'],
    'All-consumption stress-fit loading':s['profile_stress_fit_order_cost'],
    'Stress-fit saving (negative means more loading)':s['profile_stress_fit_purchase_saving']
}).to_frame('USD'))'''),
    md('''## 5. Evidence on unseen voyages: savings with a service tradeoff
The eligible-row baseline has no deficits by construction because consumption-above-loading rows were quarantined. The all-consumption stress comparison keeps those records and makes that selection effect visible. Lower unused value does not prove overall economic superiority: expediting, substitutions, guest-service penalties and carryover value are unknown. Do not add purchase savings to unused savings.'''),
    code("display(pd.DataFrame({'Primary: eligible rows':s['primary_holdout'], 'Stress: all consumption':s['stress_holdout']}))\ndisplay(pd.read_csv(OUT/'holdout_primary_voyages.csv'))\ndisplay(pd.read_csv(OUT/'risk_frontier.csv'))"),
    code("display(Image(filename=str(OUT/'evidence.png')))"),
    md('''## 6. Independent headline reconciliation
Method A uses pandas positive-part row arithmetic and sums. Method B rereads raw source strings through CSV + Decimal, independently applies validity conditions, and uses explicit branches before summing within voyages. It shares only the frozen recommendation quantities. Both methods produce $262,682.28 less unused inventory on eligible held-out records. Multiplication retains four decimals and rounds only for presentation.'''),
    code("display(pd.Series(json.loads((OUT/'headline_reconciliation.json').read_text())).to_frame('Result'))"),
    md('''## 7. VP memo and decision gates
The stress refit reverses the profile's proposed cut. Reconcile records and confirm units, case sizes, carryover, true stockouts, shortage costs and product/voyage service targets before locking standards. A controlled pilot can test the conditional saving; this sample does not establish a safe full-season reduction.'''),
    code("display(Markdown((OUT/'vp_memo.md').read_text()))"),
    md('''## Files and reproducibility
Read `outputs/analysis_report.html` for the full standalone report. `analysis.py` contains fitting, audit and independent reconciliation; `reporting.py` generates the report and memo. The CSV recommendations are accompanied by row-level held-out comparisons, model parameters, splits and the decision register.

To explore another supported profile: `conda run -n dev1 python analysis.py --nights 7 --passengers 2800 --load-factor 0.85 --sea-days-percent 0.65`. Re-running replaces outputs; it does not change input files. No results were sent to the assessor.''')
])
nb.metadata={'kernelspec':{'display_name':'Python (dev1)','language':'python','name':'python3'},
             'language_info':{'name':'python','version':sys.version.split()[0]},
             'execution_note':'All cells executed in dev1 with IPython InteractiveShell; no external kernel required.'}
shell=InteractiveShell.instance()
count=0
for cell in nb.cells:
    if cell.cell_type!='code':continue
    count+=1
    with capture_output() as captured:
        result=shell.run_cell(cell.source,store_history=True)
    if result.error_before_exec or result.error_in_exec:
        raise RuntimeError(f'Notebook cell {count} failed: {result.error_before_exec or result.error_in_exec}')
    outputs=[]
    if captured.stdout:outputs.append(nbformat.v4.new_output('stream',name='stdout',text=captured.stdout))
    if captured.stderr:outputs.append(nbformat.v4.new_output('stream',name='stderr',text=captured.stderr))
    for rich in captured.outputs:
        outputs.append(nbformat.v4.new_output('display_data',data=rich.data,metadata=rich.metadata or {}))
    cell.execution_count=count;cell.outputs=outputs
nbformat.validate(nb)
nbformat.write(nb,ROOT/'Alaska_Provisioning_Analysis.ipynb')
print(f'Executed {count} notebook cells; written Alaska_Provisioning_Analysis.ipynb')
