# The Alaska provisioning decision

Prepared October 1, 2026 · synthetic 2025 assessment data · provisional decision support

## Decision

**The VP's explanation is unsupported.** In the valid records, Alaska consumption per passenger-night is higher for all 24 products, not lower. Alaska passengers are older on average, but the adjusted age association is inconclusive and activity was never measured. This is observational evidence; it cannot establish why individual passengers eat more or less.

**A forecast with product-specific reserves reduced unused-inventory value by 11.8% on five unseen voyages, but increased shortage frequency.** The primary fit excludes 114 unresolved records that disproportionately contain high consumption. A stress refit reverses the profile's projected purchase saving. Recommend a controlled pilot after reconciliation and an approved service target; do not lock a blanket Alaska cut from this sample.

All dollar savings below are conditional inventory scenarios, not confirmed cash or destroyed-food savings. The source does not identify carryover, spoilage, substitutions, true stockouts, or unconstrained demand.

## 1. What the regional gap actually says

The file has 1,201 data rows, of which the last is a subtotal without voyage metadata. Excluding that row leaves 1,200 records: 50 voyages, 24 products and 10 ships. The Alaska and Caribbean email totals reproduce exactly: 1,685,396.62 and 801,355.58. Their ratio implies **110.3% more recorded quantity**, not 20–30%. These are sums of mixed native units across FOOD, BEVERAGE and SNACKS, so they are unsuitable as a physical-waste KPI. FOOD alone has recorded totals 911,112.24 and 391,067.44, also in mixed native units.

Alaska has **589,105 passenger-nights** versus **508,747** in the Caribbean, a 15.8% exposure difference. Count each voyage once; summing the repeated exposure on 24 product rows would inflate the denominator.

The source signed waste-cost sums are $11,872,538 in Alaska and $4,685,357 in the Caribbean. They include unexplained negative waste and are source reconciliations, not validated waste spend. Zero waste is invalid under the user's clarification; no such record is treated as true zero waste.

For a clearly labeled inventory proxy, define unused quantity as `max(provisioned - consumed, 0)`, without changing source waste. This proxy costs $12,159,007 in Alaska versus $4,943,846 in the Caribbean: $20.64 versus $9.72 per passenger-night. In the 114 unresolved records the proxy is zero by definition, which says nothing about their actual waste or inventory flows.

An exact product-by-product Shapley decomposition of the **$7,215,161 proxy-dollar gap** assigns:

- **$4,825,088 (66.9%)** to unused native quantity per passenger-night.
- **$1,203,051 (16.7%)** to passenger-night exposure.
- **$1,187,022 (16.5%)** to waste-weighted product prices.

This is an accounting decomposition, not a causal attribution. It explicitly shares interactions across the three factors. Replacing all prices with a common pooled product-median basket still shows higher Alaska loading: **$88.44 versus $71.44 per passenger-night**, while the comparable complete valid-product rate basket shows consumption **$67.75 versus $59.23**. These fixed-price baskets are valuation indices, not actual spend; valid-product rates use each product's own eligible exposure.

Across valid observations, product-level consumption increases range from **2.2% to 22.2%** in Alaska. Exclusions are unequal: **33/600 Alaska rows** and **81/600 Caribbean rows**, so complete-case comparisons may be biased. Full per-product rates are in `product_consumption_comparison.csv`.

### Age and itinerary evidence

Median ages are 54.4 (Alaska) and 44.6 (Caribbean). A primary voyage-level regression averages each valid product's passenger-night consumption rate relative to its pooled product mean. It controls for region, sea-day share, nights, passenger count and load, with HC3 uncertainty on 50 voyages. A ten-year age increase has an estimated **-0.60 percentage-point** change in this normalized index; its 95% interval is **-3.73 to 2.54 points** and includes zero. A ten-point increase in sea-day share has an estimated **6.36 point** increase (95% interval **3.44 to 9.27**).

The all-consumption, fixed-price-dollar stress regression also finds an uncertain age association and a positive sea-day association: about **$3.78 per passenger-night** for ten more percentage points at sea, with a **$1.55–$6.01** interval. Neither regression proves a passenger-age effect. Voyages on the same ship may be correlated; HC3 does not address that clustering. Unmeasured menus, passenger mix and replenishment remain possible explanations.

## 2. Explicit data-quality decisions

The originals are unchanged. `analysis.py` contains DQ01–DQ18 next to the applied logic. `data_quality_decisions.csv` lists every decision, reason and count; `audited_rows.csv` preserves source row numbers and flags so affected records can be located.

**DQ01 — Row without voyage/product metadata (spreadsheet subtotal) (count: 1).** Exclude from all voyage metrics; preserve in excluded_footer.csv. Why: Not a voyage-product observation; including it double-counts Caribbean waste.

**DQ02 — Text spelling/whitespace (count: 0).** Trim outer whitespace only; keep all 24 product identities. Why: Fuzzy merges would combine different products or units.

**DQ03 — Duplicate voyage-product keys (count: 0).** Stop if present; do not sum or drop arbitrarily. Why: Unknown whether duplicate transactions or repeated exports.

**DQ04 — Missing/nonfinite values and impossible ranges (count: 0).** Stop if any invalid numeric or required metadata value is found; do not impute. Why: Inputs are essential and arbitrary repairs could drive provisioning.

**DQ05 — Recorded waste does not equal provisioned minus consumed (count: 78).** Flag with absolute 0.02 tolerance; preserve waste and quantities unchanged. Why: No stock-flow ledger to determine which quantity is wrong.

**DQ06 — Manually added helper difference (count: 0).** Recompute gap_qty from source quantities; audit helper. Why: Helper is a check, never a modeling feature.

**DQ07 — Boolean match flag disagrees with tolerance-based arithmetic (count: 333).** Ignore supplied match as authority; use recomputed arithmetic and independent validity rules. Why: Exact floating-point equality and negative matching arithmetic do not establish data validity.

**DQ08 — Zero waste is invalid (user-confirmed) (count: 78).** Quarantine whole row from primary fit/economic comparisons; retain for demand stress test. Why: All these records also have consumption above recorded provisioned; cause unconfirmed.

**DQ09 — Negative waste needs a valid use case (count: 36).** Preserve signed original; quarantine pending documented returns/transfers/adjustments; never abs(). Why: No valid explanation has been supplied; arithmetic agreement alone is insufficient.

**DQ10 — Consumption exceeds recorded loading (count: 114).** Quarantine primary; use original consumption only in explicitly conditional stress fit/test. Why: Could indicate beginning inventory, replenishment, demand, or recording error.

**DQ11 — Repeated voyage metadata and incomplete product panels (count: 0).** Assert consistent metadata and exactly 24 distinct products per voyage; count exposure once. Why: 24 rows describe one voyage, not 24 independent voyages.

**DQ12 — Quantities combine pounds and counts; per-product units/case sizes absent (count: 24).** Keep native quantities per product; never interpret cross-product sums as weight; round up to 1 native unit only. Why: Dollar aggregation is meaningful; case rounding and units need confirmation.

**DQ13 — Large within-product price variation (count: 24).** Retain prices; use actual voyage prices in retrospective dollars and training-only Alaska medians for scenario. Why: No evidence to call positive prices errors; do not forecast regional price changes.

**DQ14 — No dates, stockouts, activity, menu, inventory carryover, or lead-time fields (count: 50).** Use deterministic voyage holdout, not chronological validation; no activity/causal claims; label leftovers as proxy. Why: Consumed need not equal unconstrained demand; unused need not equal destroyed waste.

**DQ15 — Synthetic sample and only 25 Alaska voyages (count: 25).** Pilot recommendation only; no automatic 2026 standard lock; uncertainty clustered by voyage. Why: Small sample does not establish future or simultaneous 24-product service guarantees.

**DQ16 — Ambiguous food scope and no authoritative current-policy formula (count: 1,200).** Report FOOD separately and all 24 products; compare held-out actual loading, not an invented business standard. Why: Email totals include FOOD, BEVERAGE and SNACKS.

**DQ17 — Quarantine preferentially removes high recorded demand and more Caribbean records (count: 114).** Report exclusion counts by region; score all-record demand stress and refit a stress model. Why: Complete-case fitting can understate demand; historical zero shortage in valid-only comparison is by construction.

**DQ18 — Passengers/load imply varying capacity for the same ship (>5% range) (count: 10).** Flag; keep provided pax/load separately; do not infer capacity or multiply passenger exposure by load again. Why: Rounding load to 0.01 cannot explain large differences; capacity definition needs confirmation.

There are **411 supplied False match flags**, but **333 disagree with the tolerance-based arithmetic**. Antigravity's read-only audit identified 76 floating-point-only cases and 257 one-cent rounding cases; the remaining 78 are genuine zero-waste inconsistencies. The manually added difference is accurate to floating-point tolerance. A negative quantity can match perfectly and still require a valid stock-flow explanation.

**No silent repair:** the model never substitutes absolute negative waste, never calls invalid zero waste a confirmed zero, and never uses `match`, provisioned, waste or the difference helper as a predictor of consumption.

## 3. A provisioning method that can be run next season

The planning profile is explicitly illustrative, since none was confirmed: **10 nights, 2,600 passengers, 85% load, 65% sea days**. All inputs are in the Alaska training ranges. Marginal range checks do not establish support for every combination or future ship.

Train **only on 20 Alaska voyages**, holding all products from five voyages out together. Compare three simple demand-rate models using leave-one-voyage-out errors within training: a mean rate, a sea-day linear rate, and a ridge model using all four profile fields. The selected sea-day model's mean product-relative absolute error is **12.81%**, compared with **12.99%** for a mean rate and **13.51%** for the ridge model. Its advantage over the mean is modest.

For each product, predict consumption in its own native units per passenger-night, then multiply by `nights × passengers`. The sea-day input adjusts the predicted rate. Load factor is accepted and validated but receives no independent multiplier in the selected model: actual passenger count already measures occupancy, and the four-feature model performed worse. Do not multiply passengers by load again.

The candidate order is `ceil(passenger_nights × (predicted_rate + nonnegative_reserve_rate))`. The reserve uses the rank-adjusted 95% setting of training cross-validation errors, capped at the largest available error when the rank exceeds the sample. Products have **17–20** valid training voyages. **This is an empirical safety reserve, not a 95% coverage guarantee or a proven optimum.** Selection and calibration use the same training set; overlapping CV fits and selection can make the empirical error distribution optimistic. There is no joint 24-product shortage guarantee. `model_parameters.csv` records all fitted coefficients and reserves.

No shortage cost or approved service target was supplied, so a cost-optimal newsvendor quantile cannot be determined. With overage cost `Co` and underage cost `Cu`, the economic quantile would be `Cu/(Cu+Co)` under the usual single-period assumptions. These costs must include carryover value, disposal, emergency resupply, substitution and guest-service effects. A provisional 95% setting is an assumption, not an answer from the Director.

### Quantities for the illustrative profile

Quantities below are native product units; pounds versus counts and case sizes need confirmation. Expected unused quantity estimates `mean(max(order - simulated_consumption, 0))` over the product's training CV residual scenarios. It is a **leftover proxy**, not an estimate of spoilage, plate waste or all actual food waste. One-native-unit ceiling is provisional; round to confirmed cases before ordering.

The empirical CV shortage fraction is 0% for every product at this reserve setting because it typically uses the largest observed positive error. This is optimistic and not a future-risk estimate. The table therefore also shows **observed held-out deficits** and a **one-sided exact 95% binomial upper bound**. Those bounds pool the held-out Alaska profiles; they do not estimate risk conditional on this particular profile and assume voyage events are independent and exchangeable. Rows excluded for data quality reduce the product sample to four or five voyages.

| Product | Candidate quantity | Expected unused quantity | Held-out deficits / valid voyages | 95% risk upper bound |
| --- | --- | --- | --- | --- |
| Beer (12oz) | 17,413 | 3,911 | 0/5 | 45.1% |
| Bottled Water | 71,252 | 12,832 | 0/4 | 52.7% |
| Bread Rolls | 42,457 | 8,968 | 0/5 | 45.1% |
| Chicken Breast | 16,079 | 3,635 | 0/4 | 52.7% |
| Chips | 6,651 | 1,007 | 0/4 | 52.7% |
| Chocolate Bars | 7,131 | 821 | 0/5 | 45.1% |
| Coffee Beans | 3,547 | 862 | 0/5 | 45.1% |
| Cookies | 8,399 | 1,411 | 1/5 | 65.7% |
| Fresh Fruit | 13,736 | 2,306 | 0/5 | 45.1% |
| Fresh Vegetables | 16,639 | 3,333 | 0/5 | 45.1% |
| Granola Bars | 6,046 | 962 | 2/5 | 81.1% |
| Hamburger Patties | 14,406 | 3,139 | 0/5 | 45.1% |
| Iced Tea Mix | 4,539 | 1,466 | 0/4 | 52.7% |
| Milk | 10,185 | 1,902 | 0/4 | 52.7% |
| Nuts | 5,008 | 753 | 0/5 | 45.1% |
| Orange Juice | 8,376 | 1,409 | 0/5 | 45.1% |
| Pasta | 19,434 | 4,107 | 0/4 | 52.7% |
| Pizza | 19,355 | 4,361 | 0/5 | 45.1% |
| Prime Rib | 8,669 | 1,945 | 0/5 | 45.1% |
| Rice | 14,228 | 3,216 | 0/5 | 45.1% |
| Salad Mix | 12,767 | 3,371 | 0/5 | 45.1% |
| Salmon Fillet | 9,648 | 1,846 | 0/5 | 45.1% |
| Soda Syrup | 5,126 | 970 | 0/5 | 45.1% |
| Wine (750ml) | 2,692 | 545 | 0/5 | 45.1% |

`alaska_product_recommendations.csv` also includes expected unused dollars, forecast consumption, training size, empirical risk, training price, current-practice estimate and the separate stress-fit quantity for every product.

At Alaska training-median prices, the profile's candidate loading costs **$2,294,804**, versus **$2,364,509** under a fitted historical-loading proxy, for **$69,706 (2.9%) less loading**. Expected unused inventory value is **$477,121**. The loading proxy is not an authoritative provisioning standard and should be replaced by the actual current rule when available.

**The unresolved-row sensitivity is decisive:** fitting the same model family with all training consumption records produces profile loading of **$2,634,349**, **$339,545 above the primary candidate** and **$269,839 above the historical-loading proxy**. This is not a validated alternative order either, because those records remain unresolved. It establishes that data interpretation can reverse the proposed cut.

## 4. Evidence on voyages the model did not see

Seed 2026 fixes the five Alaska holdout voyages: **AL-001, AL-004, AL-010, AL-016 and AL-018** (full IDs in `voyage_split.csv`). All 24 products for each are withheld. Test consumption never enters fitting, model selection, reserve setting, or the default planning profile. This is a retrospective grouped holdout, not a chronological test or a live trial. The trained recommendation was not retuned after viewing test results.

| Metric | Historical loading | Candidate policy |
| --- | --- | --- |
| Unused inventory value, valid rows | $2,217,705 | $1,955,023 |
| Valid product observations | 114 | 114 |
| Product deficits, valid rows | 0 | 3 |
| Voyages with any deficit, valid rows | 0/5 | 3/5 |
| Deficit at normal unit cost, valid rows | $0 | $2,866 |
| Product deficits, all-consumption stress | 6 | 8 |
| Voyages with any deficit, all-consumption stress | 4/5 | 5/5 |
| Deficit at normal unit cost, all-consumption stress | $80,792 | $110,491 |

On **114 valid product records**, unused-inventory value falls **$262,682 (11.8%)**. Loading-value savings are **$265,549**. Their **$2,866** difference is demand left unserved, valued at the normal unit price; do not describe it as an extra efficiency gain. All five voyages show positive unused-value savings; paired voyage savings are about $33,160, $78,407, $40,711, $54,900 and $55,505.

The primary historical shortage count is zero **by construction**: over-consumption records were quarantined. The recommendation has 3 deficits out of 114 eligible product-voyage observations (2.6%), but at least one deficit on **3/5 voyages (60%)**. A one-sided 95% upper bound on the voyage event probability is **92.4%** under the independent-voyage binomial model. With all recorded consumption provisionally treated as demand, there are **8 versus 6** product deficits and **5/5 versus 4/5** voyages with deficits. The model does not dominate historical loading on service risk.

This provides evidence of **lower leftover costs**, not evidence of universally better business outcomes. If emergency fulfillment costs `k × normal_unit_cost`, the eligible-row net loading saving is approximately `$265,549 - k × $2,866`, before service penalties. Its break-even multiplier is about **92.6×**. In the unresolved-demand stress, the comparable incremental threshold is about **9.8×**, assuming the same deficit penalty per dollar under each policy. Normal unit-cost deficits are a valuation proxy, not actual shortage costs. Missing emergency and guest-service penalties can erase the apparent saving.

The five-voyage paired bootstrap gives mean unused-value savings of **$52,536 per voyage**, with an illustrative 95% interval **$39,201–$66,287**. This small-sample bootstrap is descriptive; it is not a reliable coverage statement for the next season or a causal treatment effect.

For **25 similar Alaska voyages**, the same mix and prices would imply **$1,313,411 less unused inventory** and **$1,327,744 less loading**, before filling deficits and service costs. The scaled bootstrap interval is $980,014–$1,657,183. These are eligible-record scenario extrapolations, not a confirmed season forecast or a commitment against an unknown 2026 schedule. Purchase and unused savings overlap and must **not be added**.

![Evidence](evidence.png)

### Risk if the cut goes too deep

| Empirical reserve setting | Valid unused value | Valid product deficits | Stress product deficits | Profile order value |
| --- | --- | --- | --- | --- |
| 80% | $1,262,710 | 14 | 20 | $2,130,903 |
| 90% | $1,806,603 | 3 | 8 | $2,261,089 |
| 95% | $1,955,023 | 3 | 8 | $2,294,804 |
| 99% | $1,955,023 | 3 | 8 | $2,294,804 |

These alternative settings are sensitivity displays; the frozen 95% candidate remains the evaluated recommendation. Lower reserves sharply increase deficits. Raising the label from 95% to 99% produces the **same quantities** because the small residual sample saturates at its maximum. A higher label cannot create missing tail information. Product substitution, carryover, emergency resupply and a voyage-level guest-service target must be defined before final policy approval.

## 5. One headline, computed independently twice

Headline: **$262,682 less unused inventory on the five held-out voyages** (eligible records; exact cents **$262682.28**).

**Method A:** pandas row-wise positive-part arithmetic followed by aggregation of `historical_unused_value - proposed_unused_value`, on 114 valid held-out records. Result: **262682.2837000000**.

**Method B:** read original source strings independently with Python's CSV reader and Decimal; independently apply the documented validity conditions, join only the frozen recommended quantities, use explicit `if quantity > consumed` arithmetic, aggregate within each voyage, then sum voyage results. Result: **262682.2837**. No pandas cleaning flags or derived cost columns are reused.

The difference is **-3e-11 dollars**, solely binary floating-point noise. Both reconcile to **$262682.28**. The source Alaska quantity also independently reconciles to **1,685,396.62**, and its signed dollar sum to **$11,872,537.9976**. `headline_reconciliation.json` records all values and per-voyage Decimal results. Monetary multiplication retains four decimals internally and rounds once at presentation; summing separately rounded row costs can differ slightly.

## 6. Three-week implementation decision

1. **Week 1: reconcile.** Investigate all 114 flagged records using opening inventory, replenishments, transfers, returns and closing stock. Confirm whether any negative waste is a valid adjustment. Separate destroyed food from usable carryover and record per-product units/case sizes. Confirm passenger and load definitions; implied capacities vary for every ship.
2. **Week 2: define risk and pilot.** Agree product-level and voyage-level service targets, shortage penalties and substitution rules. Replace the fitted loading proxy with the real current standard. Use prospective demand logging and monitor shortages, substitutions and discarded inventory on a small controlled pilot; backtest reconciled inventory independently.
3. **Week 3: lock only supported standards.** Accept a product's cut only when the stock-flow ledger is reconciled and its service risk is acceptable. Preserve appropriate emergency stock for long lead times and products without substitutions. If the pilot cannot establish that in time, retain current standards for affected products rather than claiming a certified safety margin.

Scope cut: no individual passenger-level causal claim, no ship/menu interactions with too little data, no unverifiable activity proxy, no inferred lbs-to-count conversion, no optimization against unknown shortage costs, no claimed destroyed-food/cash savings from leftovers, and no invented future itinerary schedule.

## Reproduce and inspect

From the project folder:

```sh
conda run -n dev1 python analysis.py
```

For another profile within training ranges:

```sh
conda run -n dev1 python analysis.py --nights 7 --passengers 2800 --load-factor 0.85 --sea-days-percent 0.65
```

`--sea-days-percent` is a fraction (0.65), not 65. Re-running overwrites generated outputs but never the input files. Forecast controls, quality decisions and all derived files are visible in code. `Alaska_Provisioning_Analysis.ipynb` provides a readable, executed walkthrough. `vp_memo.md` is 183 words including its header. Dependencies: numpy, pandas, scipy, scikit-learn, statsmodels, matplotlib and markdown; the notebook also uses nbformat and IPython. Inputs are synthetic per the Word brief. SHA-256 of the CSV: `f2455d9c94e203e708ff1422756c5164ada83b1142d78641f83c9f3a8ca64774`.
