To: VP Hotel Operations
Subject: Alaska provisioning decision — provisional pilot

Your age-and-activity explanation is unsupported: Alaska consumption per passenger-night is higher for every product in the valid records, and activity is unmeasured.

The quoted quantities differ by 110%, not 20–30%, and mix pounds with counts. Alaska has 16% more passenger-nights. A conditional dollar decomposition attributes most excess unused inventory to higher leftovers per passenger-night, with smaller exposure and price effects. Sea-day share is associated with consumption; age is inconclusive.

For an illustrative 10-night, 2,600-passenger voyage at 85% load and 65% sea days, use the attached product forecasts plus reserves as a pilot candidate. Estimated loading falls $69,706; expected unused inventory is $477,121.

On five unseen voyages, eligible records show $262,682 less unused inventory (11.8%), equivalent to $1,313,411 over 25 similar voyages, conditionally. Three product deficits occurred across three voyages. This does not establish acceptable service risk.

Do not lock blanket cuts yet. Reconcile 78 invalid zero-waste and 36 unexplained negative-waste records; including their consumption raises profile inventory $339,545. Confirm carryover, stockouts, units, case sizes, shortage costs and service targets before final standards.
