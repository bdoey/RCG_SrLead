"""Generate human-readable deliverables from verified analysis outputs."""
import base64, json, html
from pathlib import Path
import pandas as pd
import markdown

def money(x): return f'${x:,.0f}'
def table(headers, rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+
        ['| '+' | '.join(str(x).replace('|','/') for x in r)+' |' for r in rows])

def write_reports(root,out,s):
    p=s['primary_holdout'];st=s['stress_holdout'];prof=s['profile']
    plan=pd.read_csv(out/'alaska_product_recommendations.csv')
    reg=pd.read_csv(out/'regional_summary.csv').set_index('region')
    dq=pd.read_csv(out/'data_quality_decisions.csv')
    recon=json.loads((out/'headline_reconciliation.json').read_text())
    frontier=pd.read_csv(out/'risk_frontier.csv')
    a,c=reg.loc['ALASKA'],reg.loc['CARIBBEAN']
    gap=s['gap_decomposition'];totalgap=sum(gap.values())
    valid=p['rows'];invalid=120-valid
    memo=f'''To: VP Hotel Operations
Subject: Alaska provisioning decision — provisional pilot

Your age-and-activity explanation is unsupported: Alaska consumption per passenger-night is higher for every product in the valid records, and activity is unmeasured.

The quoted quantities differ by 110%, not 20–30%, and mix pounds with counts. Alaska has 16% more passenger-nights. A conditional dollar decomposition attributes most excess unused inventory to higher leftovers per passenger-night, with smaller exposure and price effects. Sea-day share is associated with consumption; age is inconclusive.

For an illustrative {prof['nights']}-night, {prof['passengers']:,}-passenger voyage at {prof['load_factor']:.0%} load and {prof['sea_days_percent']:.0%} sea days, use the attached product forecasts plus reserves as a pilot candidate. Estimated loading falls {money(s['profile_purchase_saving'])}; expected unused inventory is {money(s['profile_expected_unused_cost'])}.

On five unseen voyages, eligible records show {money(p['unused_saving'])} less unused inventory ({p['unused_reduction_pct']:.1f}%), equivalent to {money(s['projected_25_voyage_unused_saving'])} over 25 similar voyages, conditionally. Three product deficits occurred across three voyages. This does not establish acceptable service risk.

Do not lock blanket cuts yet. Reconcile 78 invalid zero-waste and 36 unexplained negative-waste records; including their consumption raises profile inventory {money(s['profile_stress_fit_order_cost']-s['profile_order_cost'])}. Confirm carryover, stockouts, units, case sizes, shortage costs and service targets before final standards.'''
    wordcount=len(memo.split())
    assert wordcount<=200, f'Memo too long: {wordcount}'
    (out/'vp_memo.md').write_text(memo+'\n')
    qtyrows=[]
    for r in plan.itertuples():
        qtyrows.append([r.product_name,f'{r.recommended_qty:,.0f}',f'{r.expected_unused_qty:,.0f}',
            f'{r.holdout_shortage_events}/{r.holdout_valid_voyages}',
            f'{r.holdout_shortage_probability_95_upper:.1%}'])
    dqtext='\n\n'.join(f"**{r.id} — {r.problem} (count: {r.count:,}).** {r.decision}. Why: {r.why}." for r in dq.itertuples())
    comparison=table(['Metric','Historical loading','Candidate policy'],[
        ['Unused inventory value, valid rows',money(p['current_unused_cost']),money(p['new_unused_cost'])],
        ['Valid product observations',valid,valid],
        ['Product deficits, valid rows',p['current_shortage_rows'],p['new_shortage_rows']],
        ['Voyages with any deficit, valid rows',f"{p['current_any_shortage_voyages']}/5",f"{p['new_any_shortage_voyages']}/5"],
        ['Deficit at normal unit cost, valid rows',money(p['current_shortfall_value']),money(p['new_shortfall_value'])],
        ['Product deficits, all-consumption stress',st['current_shortage_rows'],st['new_shortage_rows']],
        ['Voyages with any deficit, all-consumption stress',f"{st['current_any_shortage_voyages']}/5",f"{st['new_any_shortage_voyages']}/5"],
        ['Deficit at normal unit cost, all-consumption stress',money(st['current_shortfall_value']),money(st['new_shortfall_value'])],
    ])
    front=table(['Empirical reserve setting','Valid unused value','Valid product deficits','Stress product deficits','Profile order value'],
        [[f'{r.quantile:.0%}',money(r.valid_unused_cost),r.valid_shortage_rows,r.stress_shortage_rows,money(r.scenario_order_cost)] for r in frontier.itertuples()])
    report=f'''# The Alaska provisioning decision

Prepared October 1, 2026 · synthetic 2025 assessment data · provisional decision support

## Decision

**The VP's explanation is unsupported.** In the valid records, Alaska consumption per passenger-night is higher for all 24 products, not lower. Alaska passengers are older on average, but the adjusted age association is inconclusive and activity was never measured. This is observational evidence; it cannot establish why individual passengers eat more or less.

**A forecast with product-specific reserves reduced unused-inventory value by {p['unused_reduction_pct']:.1f}% on five unseen voyages, but increased shortage frequency.** The primary fit excludes 114 unresolved records that disproportionately contain high consumption. A stress refit reverses the profile's projected purchase saving. Recommend a controlled pilot after reconciliation and an approved service target; do not lock a blanket Alaska cut from this sample.

All dollar savings below are conditional inventory scenarios, not confirmed cash or destroyed-food savings. The source does not identify carryover, spoilage, substitutions, true stockouts, or unconstrained demand.

## 1. What the regional gap actually says

The file has 1,201 data rows, of which the last is a subtotal without voyage metadata. Excluding that row leaves 1,200 records: 50 voyages, 24 products and 10 ships. The Alaska and Caribbean email totals reproduce exactly: 1,685,396.62 and 801,355.58. Their ratio implies **110.3% more recorded quantity**, not 20–30%. These are sums of mixed native units across FOOD, BEVERAGE and SNACKS, so they are unsuitable as a physical-waste KPI. FOOD alone has recorded totals 911,112.24 and 391,067.44, also in mixed native units.

Alaska has **589,105 passenger-nights** versus **508,747** in the Caribbean, a 15.8% exposure difference. Count each voyage once; summing the repeated exposure on 24 product rows would inflate the denominator.

The source signed waste-cost sums are {money(a.reported_signed_cost)} in Alaska and {money(c.reported_signed_cost)} in the Caribbean. They include unexplained negative waste and are source reconciliations, not validated waste spend. Zero waste is invalid under the user's clarification; no such record is treated as true zero waste.

For a clearly labeled inventory proxy, define unused quantity as `max(provisioned - consumed, 0)`, without changing source waste. This proxy costs {money(a.proxy_unused_cost_all)} in Alaska versus {money(c.proxy_unused_cost_all)} in the Caribbean: ${a.proxy_unused_cost_per_passenger_night:.2f} versus ${c.proxy_unused_cost_per_passenger_night:.2f} per passenger-night. In the 114 unresolved records the proxy is zero by definition, which says nothing about their actual waste or inventory flows.

An exact product-by-product Shapley decomposition of the **{money(totalgap)} proxy-dollar gap** assigns:

- **{money(gap['unused_rate'])} ({gap['unused_rate']/totalgap:.1%})** to unused native quantity per passenger-night.
- **{money(gap['exposure'])} ({gap['exposure']/totalgap:.1%})** to passenger-night exposure.
- **{money(gap['price'])} ({gap['price']/totalgap:.1%})** to waste-weighted product prices.

This is an accounting decomposition, not a causal attribution. It explicitly shares interactions across the three factors. Replacing all prices with a common pooled product-median basket still shows higher Alaska loading: **$88.44 versus $71.44 per passenger-night**, while the comparable complete valid-product rate basket shows consumption **$67.75 versus $59.23**. These fixed-price baskets are valuation indices, not actual spend; valid-product rates use each product's own eligible exposure.

Across valid observations, product-level consumption increases range from **2.2% to 22.2%** in Alaska. Exclusions are unequal: **33/600 Alaska rows** and **81/600 Caribbean rows**, so complete-case comparisons may be biased. Full per-product rates are in `product_consumption_comparison.csv`.

### Age and itinerary evidence

Median ages are 54.4 (Alaska) and 44.6 (Caribbean). A primary voyage-level regression averages each valid product's passenger-night consumption rate relative to its pooled product mean. It controls for region, sea-day share, nights, passenger count and load, with HC3 uncertainty on 50 voyages. A ten-year age increase has an estimated **{s['primary_age_effect_per_year']*1000:.2f} percentage-point** change in this normalized index; its 95% interval is **{s['primary_age_ci95'][0]*1000:.2f} to {s['primary_age_ci95'][1]*1000:.2f} points** and includes zero. A ten-point increase in sea-day share has an estimated **{s['primary_sea_effect_10pct']*100:.2f} point** increase (95% interval **{s['primary_sea_ci95'][0]*100:.2f} to {s['primary_sea_ci95'][1]*100:.2f}**).

The all-consumption, fixed-price-dollar stress regression also finds an uncertain age association and a positive sea-day association: about **${s['sea_effect_10pct']:.2f} per passenger-night** for ten more percentage points at sea, with a **${s['sea_effect_10pct_ci95'][0]:.2f}–${s['sea_effect_10pct_ci95'][1]:.2f}** interval. Neither regression proves a passenger-age effect. Voyages on the same ship may be correlated; HC3 does not address that clustering. Unmeasured menus, passenger mix and replenishment remain possible explanations.

## 2. Explicit data-quality decisions

The originals are unchanged. `analysis.py` contains DQ01–DQ18 next to the applied logic. `data_quality_decisions.csv` lists every decision, reason and count; `audited_rows.csv` preserves source row numbers and flags so affected records can be located.

{dqtext}

There are **411 supplied False match flags**, but **333 disagree with the tolerance-based arithmetic**. Antigravity's read-only audit identified 76 floating-point-only cases and 257 one-cent rounding cases; the remaining 78 are genuine zero-waste inconsistencies. The manually added difference is accurate to floating-point tolerance. A negative quantity can match perfectly and still require a valid stock-flow explanation.

**No silent repair:** the model never substitutes absolute negative waste, never calls invalid zero waste a confirmed zero, and never uses `match`, provisioned, waste or the difference helper as a predictor of consumption.

## 3. A provisioning method that can be run next season

The planning profile is explicitly illustrative, since none was confirmed: **{prof['nights']} nights, {prof['passengers']:,} passengers, {prof['load_factor']:.0%} load, {prof['sea_days_percent']:.0%} sea days**. All inputs are in the Alaska training ranges. Marginal range checks do not establish support for every combination or future ship.

Train **only on 20 Alaska voyages**, holding all products from five voyages out together. Compare three simple demand-rate models using leave-one-voyage-out errors within training: a mean rate, a sea-day linear rate, and a ridge model using all four profile fields. The selected sea-day model's mean product-relative absolute error is **12.81%**, compared with **12.99%** for a mean rate and **13.51%** for the ridge model. Its advantage over the mean is modest.

For each product, predict consumption in its own native units per passenger-night, then multiply by `nights × passengers`. The sea-day input adjusts the predicted rate. Load factor is accepted and validated but receives no independent multiplier in the selected model: actual passenger count already measures occupancy, and the four-feature model performed worse. Do not multiply passengers by load again.

The candidate order is `ceil(passenger_nights × (predicted_rate + nonnegative_reserve_rate))`. The reserve uses the rank-adjusted 95% setting of training cross-validation errors, capped at the largest available error when the rank exceeds the sample. Products have **17–20** valid training voyages. **This is an empirical safety reserve, not a 95% coverage guarantee or a proven optimum.** Selection and calibration use the same training set; overlapping CV fits and selection can make the empirical error distribution optimistic. There is no joint 24-product shortage guarantee. `model_parameters.csv` records all fitted coefficients and reserves.

No shortage cost or approved service target was supplied, so a cost-optimal newsvendor quantile cannot be determined. With overage cost `Co` and underage cost `Cu`, the economic quantile would be `Cu/(Cu+Co)` under the usual single-period assumptions. These costs must include carryover value, disposal, emergency resupply, substitution and guest-service effects. A provisional 95% setting is an assumption, not an answer from the Director.

### Quantities for the illustrative profile

Quantities below are native product units; pounds versus counts and case sizes need confirmation. Expected unused quantity estimates `mean(max(order - simulated_consumption, 0))` over the product's training CV residual scenarios. It is a **leftover proxy**, not an estimate of spoilage, plate waste or all actual food waste. One-native-unit ceiling is provisional; round to confirmed cases before ordering.

The empirical CV shortage fraction is 0% for every product at this reserve setting because it typically uses the largest observed positive error. This is optimistic and not a future-risk estimate. The table therefore also shows **observed held-out deficits** and a **one-sided exact 95% binomial upper bound**. Those bounds pool the held-out Alaska profiles; they do not estimate risk conditional on this particular profile and assume voyage events are independent and exchangeable. Rows excluded for data quality reduce the product sample to four or five voyages.

{table(['Product','Candidate quantity','Expected unused quantity','Held-out deficits / valid voyages','95% risk upper bound'],qtyrows)}

`alaska_product_recommendations.csv` also includes expected unused dollars, forecast consumption, training size, empirical risk, training price, current-practice estimate and the separate stress-fit quantity for every product.

At Alaska training-median prices, the profile's candidate loading costs **{money(s['profile_order_cost'])}**, versus **{money(s['profile_current_practice_estimate_cost'])}** under a fitted historical-loading proxy, for **{money(s['profile_purchase_saving'])} ({s['profile_purchase_saving']/s['profile_current_practice_estimate_cost']:.1%}) less loading**. Expected unused inventory value is **{money(s['profile_expected_unused_cost'])}**. The loading proxy is not an authoritative provisioning standard and should be replaced by the actual current rule when available.

**The unresolved-row sensitivity is decisive:** fitting the same model family with all training consumption records produces profile loading of **{money(s['profile_stress_fit_order_cost'])}**, **{money(s['profile_stress_fit_order_cost']-s['profile_order_cost'])} above the primary candidate** and **{money(-s['profile_stress_fit_purchase_saving'])} above the historical-loading proxy**. This is not a validated alternative order either, because those records remain unresolved. It establishes that data interpretation can reverse the proposed cut.

## 4. Evidence on voyages the model did not see

Seed 2026 fixes the five Alaska holdout voyages: **AL-001, AL-004, AL-010, AL-016 and AL-018** (full IDs in `voyage_split.csv`). All 24 products for each are withheld. Test consumption never enters fitting, model selection, reserve setting, or the default planning profile. This is a retrospective grouped holdout, not a chronological test or a live trial. The trained recommendation was not retuned after viewing test results.

{comparison}

On **114 valid product records**, unused-inventory value falls **{money(p['unused_saving'])} ({p['unused_reduction_pct']:.1f}%)**. Loading-value savings are **{money(p['purchase_saving'])}**. Their **{money(p['new_shortfall_value'])}** difference is demand left unserved, valued at the normal unit price; do not describe it as an extra efficiency gain. All five voyages show positive unused-value savings; paired voyage savings are about $33,160, $78,407, $40,711, $54,900 and $55,505.

The primary historical shortage count is zero **by construction**: over-consumption records were quarantined. The recommendation has 3 deficits out of 114 eligible product-voyage observations (2.6%), but at least one deficit on **3/5 voyages (60%)**. A one-sided 95% upper bound on the voyage event probability is **92.4%** under the independent-voyage binomial model. With all recorded consumption provisionally treated as demand, there are **8 versus 6** product deficits and **5/5 versus 4/5** voyages with deficits. The model does not dominate historical loading on service risk.

This provides evidence of **lower leftover costs**, not evidence of universally better business outcomes. If emergency fulfillment costs `k × normal_unit_cost`, the eligible-row net loading saving is approximately `{money(p['purchase_saving'])} - k × {money(p['new_shortfall_value'])}`, before service penalties. Its break-even multiplier is about **{p['purchase_saving']/p['new_shortfall_value']:.1f}×**. In the unresolved-demand stress, the comparable incremental threshold is about **{st['purchase_saving']/(st['new_shortfall_value']-st['current_shortfall_value']):.1f}×**, assuming the same deficit penalty per dollar under each policy. Normal unit-cost deficits are a valuation proxy, not actual shortage costs. Missing emergency and guest-service penalties can erase the apparent saving.

The five-voyage paired bootstrap gives mean unused-value savings of **{money(p['unused_saving']/5)} per voyage**, with an illustrative 95% interval **{money(p['mean_unused_saving_bootstrap95'][0])}–{money(p['mean_unused_saving_bootstrap95'][1])}**. This small-sample bootstrap is descriptive; it is not a reliable coverage statement for the next season or a causal treatment effect.

For **25 similar Alaska voyages**, the same mix and prices would imply **{money(s['projected_25_voyage_unused_saving'])} less unused inventory** and **{money(s['projected_25_voyage_purchase_saving'])} less loading**, before filling deficits and service costs. The scaled bootstrap interval is {money(s['projected_25_voyage_unused_saving_bootstrap95'][0])}–{money(s['projected_25_voyage_unused_saving_bootstrap95'][1])}. These are eligible-record scenario extrapolations, not a confirmed season forecast or a commitment against an unknown 2026 schedule. Purchase and unused savings overlap and must **not be added**.

![Evidence](evidence.png)

### Risk if the cut goes too deep

{front}

These alternative settings are sensitivity displays; the frozen 95% candidate remains the evaluated recommendation. Lower reserves sharply increase deficits. Raising the label from 95% to 99% produces the **same quantities** because the small residual sample saturates at its maximum. A higher label cannot create missing tail information. Product substitution, carryover, emergency resupply and a voyage-level guest-service target must be defined before final policy approval.

## 5. One headline, computed independently twice

Headline: **{money(p['unused_saving'])} less unused inventory on the five held-out voyages** (eligible records; exact cents **${recon['reconciled_headline_cents']}**).

**Method A:** pandas row-wise positive-part arithmetic followed by aggregation of `historical_unused_value - proposed_unused_value`, on 114 valid held-out records. Result: **{recon['pandas_holdout_unused_saving']:.10f}**.

**Method B:** read original source strings independently with Python's CSV reader and Decimal; independently apply the documented validity conditions, join only the frozen recommended quantities, use explicit `if quantity > consumed` arithmetic, aggregate within each voyage, then sum voyage results. Result: **{recon['decimal_holdout_unused_saving']}**. No pandas cleaning flags or derived cost columns are reused.

The difference is **{recon['saving_difference']:.2g} dollars**, solely binary floating-point noise. Both reconcile to **${recon['reconciled_headline_cents']}**. The source Alaska quantity also independently reconciles to **1,685,396.62**, and its signed dollar sum to **$11,872,537.9976**. `headline_reconciliation.json` records all values and per-voyage Decimal results. Monetary multiplication retains four decimals internally and rounds once at presentation; summing separately rounded row costs can differ slightly.

## 6. Three-week implementation decision

1. **Week 1: reconcile.** Investigate all 114 flagged records using opening inventory, replenishments, transfers, returns and closing stock. Confirm whether any negative waste is a valid adjustment. Separate destroyed food from usable carryover and record per-product units/case sizes. Confirm passenger and load definitions; implied capacities vary for every ship.
2. **Week 2: define risk and pilot.** Agree product-level and voyage-level service targets, shortage penalties and substitution rules. Replace the fitted loading proxy with the real current standard. Use prospective demand logging and monitor shortages, substitutions and discarded inventory on a small controlled pilot; backtest reconciled inventory independently.
3. **Week 3: lock only supported standards.** Accept a product's cut only when the stock-flow ledger is reconciled and its service risk is acceptable. Preserve appropriate emergency stock for long lead times and products without substitutions. If the pilot cannot establish that in time, retain current standards for affected products rather than claiming a certified safety margin.

Scope cut: no individual passenger-level causal claim, no ship/menu interactions with too little data, no unverifiable activity proxy, no inferred lbs-to-count conversion, no optimization against unknown shortage costs, no claimed destroyed-food/cash savings from leftovers, and no invented future itinerary schedule.

## Reproduce and inspect

From the project folder:

```sh
conda run -n dev1 python analysis.py
```

For another profile within training ranges:

```sh
conda run -n dev1 python analysis.py --nights 7 --passengers 2800 --load-factor 0.85 --sea-days-percent 0.65
```

`--sea-days-percent` is a fraction (0.65), not 65. Re-running overwrites generated outputs but never the input files. Forecast controls, quality decisions and all derived files are visible in code. `Alaska_Provisioning_Analysis.ipynb` provides a readable, executed walkthrough. `vp_memo.md` is {wordcount} words including its header. Dependencies: numpy, pandas, scipy, scikit-learn, statsmodels, matplotlib and markdown; the notebook also uses nbformat and IPython. Inputs are synthetic per the Word brief. SHA-256 of the CSV: `{s['source_sha256']}`.
'''
    (out/'analysis_report.md').write_text(report)
    image=base64.b64encode((out/'evidence.png').read_bytes()).decode()
    reporthtml=markdown.markdown(report.replace('(evidence.png)',f'(data:image/png;base64,{image})'),extensions=['tables','fenced_code'])
    css='''body{font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;color:#24323b;background:#f5f7f8;margin:0}main{max-width:1080px;margin:30px auto;padding:45px;background:white}h1{font-size:34px;color:#155c6c;line-height:1.2}h2{font-size:24px;color:#155c6c;margin-top:36px;border-top:1px solid #dce6e9;padding-top:20px}h3{font-size:20px}p,li{max-width:100%}table{border-collapse:collapse;width:100%;font-size:13px;margin:20px 0}th{background:#e5f0f3;text-align:left}td,th{border-bottom:1px solid #dce6e9;padding:8px;vertical-align:top}tr:nth-child(even){background:#f8fafb}pre{padding:16px;background:#eff3f5;overflow:auto}code{font-size:13px}img{width:100%;height:auto}a{color:#15667c}@media print{body{background:white;font-size:10pt}main{padding:0;margin:0}h2,h3{break-after:avoid}tr{break-inside:avoid}table{font-size:8pt}pre{white-space:pre-wrap}}'''
    (out/'analysis_report.html').write_text(f'<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Alaska provisioning decision</title><style>{css}</style><main>{reporthtml}</main></html>')
